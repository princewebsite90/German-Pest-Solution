# German Pest Solution — APK बनाने की गाइड

यह पैकेज Flutter source code है; इसमें पहले से compiled APK शामिल नहीं है। इस वातावरण में Flutter/Android build SDK उपलब्ध नहीं है, इसलिए APK को यहीं compile करना संभव नहीं हुआ। साथ में GitHub Actions workflow जोड़ा गया है, जो GitHub पर source upload करने के बाद APK build करके डाउनलोड करने योग्य artifact बनाएगा।

## APK पाने का तरीका (कंप्यूटर/ब्राउज़र से)
1. GitHub पर नया repository बनाएं, जैसे `german-pest-solution`.
2. इस ZIP को extract करें और उसके अंदर के सभी files/folders repository में upload करें. `.github/workflows/build-android-apk.yml` भी upload होना चाहिए.
3. GitHub repository खोलें → **Actions** tab → **Build Android APK** workflow चुनें → **Run workflow** दबाएं.
4. Build पूरा होने पर workflow run खोलें. नीचे **Artifacts** में `german-pest-solution-release-apk` डाउनलोड करें.
5. Artifact ZIP को extract करें; उसमें `app-release.apk` होगा. उसे Android फोन पर भेजकर install करें. Android पूछे तो केवल इसी APK के लिए “Install unknown apps” की अनुमति दें.

## ध्यान दें
- यह app अभी starter/demo है. README के अनुसार booking server पर save नहीं होती और phone login वास्तविक OTP नहीं है.
- ऐप publish/share करने से पहले `lib/core/app_config.dart` में संपर्क विवरण और service prices verify करें.
- GitHub Actions में build fail हो तो log का आखिरी error हिस्सा साझा करें.
