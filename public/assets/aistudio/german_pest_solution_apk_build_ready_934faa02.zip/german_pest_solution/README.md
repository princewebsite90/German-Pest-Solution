# German Pest Solution — Flutter Starter

A feature-first Flutter starter app with a premium blue/green theme, animated splash screen, service catalog, service selection, booking form, and WhatsApp/phone contact actions.

## Requirements
- Flutter SDK (Dart >= 3.2)
- Android Studio or VS Code with Flutter extension

## Run
```bash
flutter pub get
flutter run
```

If creating a fresh Flutter project, these source files are already arranged under `lib/`.

## Important notes
- Booking submission is a local demo only; it does not save bookings to a server.
- Phone login is a demo flow, not real OTP authentication.
- Catalog prices are sample placeholders. Verify them against German Pest Solution's approved price list before publishing.
- Replace contact numbers and website in `lib/core/app_config.dart` if needed.
- Image URLs require internet access; if an image fails, the UI displays a fallback icon.
