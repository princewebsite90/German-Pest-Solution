import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/app_config.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../models/service_model.dart';
import '../../state/app_providers.dart';
import '../auth/login_bottom_sheet.dart';
import '../booking/booking_screen.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  Future<void> _call() async {
    final uri = Uri.parse('tel:${AppConfig.primaryPhone}');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(isAuthenticatedProvider);
    final phone = ref.watch(userPhoneProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('German Pest Solution', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          Text('Professional pest control', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ]),
        actions: [
          IconButton(
            tooltip: auth ? (phone ?? 'Signed in') : 'Login',
            onPressed: () => LoginBottomSheet.show(context),
            icon: Icon(auth ? Icons.account_circle_rounded : Icons.person_outline_rounded, size: 27),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: CustomScrollView(slivers: [
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 8, 18, 20),
          child: Container(
            padding: const EdgeInsets.all(22),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [AppColors.primaryDarkBlue, AppColors.secondaryBlue], begin: Alignment.topLeft, end: Alignment.bottomRight),
              borderRadius: BorderRadius.circular(24),
              boxShadow: AppTheme.softShadow,
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: AppColors.yellow, borderRadius: BorderRadius.circular(30)),
                child: const Text('HOME • OFFICE • COMMERCIAL', style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: AppColors.primaryDarkBlue))),
              const SizedBox(height: 16),
              const Text('A cleaner space.\nA stronger line of defence.', style: TextStyle(fontSize: 25, height: 1.18, fontWeight: FontWeight.w800, color: Colors.white)),
              const SizedBox(height: 10),
              Text('Pest control solutions tailored to your property.', style: TextStyle(color: Colors.white.withOpacity(.8), fontSize: 13)),
              const SizedBox(height: 20),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: AppColors.yellow, foregroundColor: AppColors.primaryDarkBlue),
                onPressed: () { AppHaptics.light(); _call(); },
                icon: const Icon(Icons.call_rounded), label: const Text('Call for service', style: TextStyle(fontWeight: FontWeight.w700)),
              ),
            ]),
          ),
        )),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 14),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            const Text('Explore our services', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w800)),
            Text('${kPestServices.length} services', style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
          ]),
        )),
        SliverPadding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 28),
          sliver: SliverGrid(
            delegate: SliverChildBuilderDelegate((context, index) {
              final service = kPestServices[index];
              return _ServiceCard(service: service, onTap: () {
                AppHaptics.selection();
                Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookingScreen(service: service)));
              });
            }, childCount: kPestServices.length),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: .94,
            ),
          ),
        ),
        SliverToBoxAdapter(child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 0, 20, 26),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.cardBorder)),
            child: const Row(children: [
              Icon(Icons.verified_user_outlined, color: AppColors.successGreen, size: 30),
              SizedBox(width: 12),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('Service across Delhi NCR', style: TextStyle(fontWeight: FontWeight.w700)),
                SizedBox(height: 3),
                Text('Delhi • Noida • Gurgaon • Faridabad • Ghaziabad', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
              ])),
            ]),
          ),
        )),
      ]),
      floatingActionButton: FloatingActionButton(
        onPressed: _call,
        backgroundColor: AppColors.successGreen,
        foregroundColor: Colors.white,
        tooltip: 'Call German Pest Solution',
        child: const Icon(Icons.call_rounded),
      ),
    );
  }
}

class _ServiceCard extends StatelessWidget {
  final PestServiceModel service;
  final VoidCallback onTap;
  const _ServiceCard({required this.service, required this.onTap});

  @override
  Widget build(BuildContext context) => Material(
    color: Colors.white,
    borderRadius: BorderRadius.circular(18),
    child: InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.cardBorder)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(width: 48, height: 48, decoration: BoxDecoration(color: AppColors.softGreen, borderRadius: BorderRadius.circular(14)),
            child: Icon(service.icon, color: AppColors.primaryDarkBlue, size: 27)),
          const Spacer(),
          Text(service.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
          const SizedBox(height: 5),
          Text(service.subtitle, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 10.5, height: 1.3, color: AppColors.textSecondary)),
          const SizedBox(height: 10),
          const Row(children: [Text('View service', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: AppColors.secondaryBlue)), Spacer(), Icon(Icons.arrow_forward_rounded, size: 16, color: AppColors.secondaryBlue)]),
        ]),
      ),
    ),
  );
}
