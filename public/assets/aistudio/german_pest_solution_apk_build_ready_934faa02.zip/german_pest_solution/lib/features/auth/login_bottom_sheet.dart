import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../state/app_providers.dart';

class LoginBottomSheet extends ConsumerStatefulWidget {
  const LoginBottomSheet({super.key});
  static Future<void> show(BuildContext context) => showModalBottomSheet<void>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black.withOpacity(.35),
        builder: (_) => const LoginBottomSheet(),
      );

  @override
  ConsumerState<LoginBottomSheet> createState() => _LoginBottomSheetState();
}

class _LoginBottomSheetState extends ConsumerState<LoginBottomSheet> {
  final _phoneController = TextEditingController();
  bool _busy = false;

  Future<void> _continue() async {
    AppHaptics.medium();
    final phone = _phoneController.text.trim();
    if (!RegExp(r'^[6-9]\d{9}$').hasMatch(phone)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter a valid 10-digit Indian mobile number.')));
      return;
    }
    setState(() => _busy = true);
    await Future.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;
    ref.read(isAuthenticatedProvider.notifier).state = true;
    ref.read(userPhoneProvider.notifier).state = '+91 $phone';
    AppHaptics.success();
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Demo sign-in complete. Real OTP is not configured.')));
  }

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final inset = MediaQuery.of(context).viewInsets.bottom;
    return BackdropFilter(
      filter: ImageFilter.blur(sigmaX: 7, sigmaY: 7),
      child: Padding(
        padding: EdgeInsets.only(bottom: inset),
        child: Container(
          padding: const EdgeInsets.fromLTRB(22, 14, 22, 28),
          decoration: const BoxDecoration(color: Colors.white, borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Center(child: Container(width: 42, height: 5, decoration: BoxDecoration(color: Colors.black12, borderRadius: BorderRadius.circular(8)))),
              const SizedBox(height: 22),
              const Text('Welcome back', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w800, color: AppColors.primaryDarkBlue)),
              const SizedBox(height: 6),
              const Text('Enter your mobile number to continue.', style: TextStyle(color: AppColors.textSecondary)),
              const SizedBox(height: 20),
              TextField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                maxLength: 10,
                decoration: const InputDecoration(prefixText: '+91  ', labelText: 'Mobile number', counterText: ''),
              ),
              const SizedBox(height: 16),
              SizedBox(width: double.infinity, height: 52, child: FilledButton(
                onPressed: _busy ? null : _continue,
                child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Text('Continue'),
              )),
              const SizedBox(height: 10),
              const Text('Demo only: this screen does not send an actual OTP.', style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ]),
          ),
        ),
      ),
    );
  }
}
