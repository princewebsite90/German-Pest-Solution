import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/haptics.dart';
import '../../models/service_model.dart';

class BookingScreen extends StatefulWidget {
  final PestServiceModel service;
  const BookingScreen({super.key, required this.service});

  @override
  State<BookingScreen> createState() => _BookingScreenState();
}

class _BookingScreenState extends State<BookingScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _notes = TextEditingController();
  String? _property;
  DateTime? _date;

  @override
  void dispose() {
    _name.dispose(); _phone.dispose(); _address.dispose(); _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final chosen = await showDatePicker(
      context: context,
      initialDate: now.add(const Duration(days: 1)),
      firstDate: now,
      lastDate: now.add(const Duration(days: 90)),
    );
    if (chosen != null) setState(() => _date = chosen);
  }

  void _submit() {
    if (_name.text.trim().isEmpty || !RegExp(r'^[6-9]\d{9}$').hasMatch(_phone.text.trim()) ||
        _address.text.trim().isEmpty || _property == null || _date == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please complete your name, valid phone, address, property size and preferred date.')));
      return;
    }
    AppHaptics.success();
    final price = widget.service.pricingByProperty[_property!];
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        icon: const Icon(Icons.check_circle_rounded, color: AppColors.successGreen, size: 42),
        title: const Text('Booking request prepared'),
        content: Text('Service: ${widget.service.title}\nProperty: $_property\nIndicative price: ₹${price ?? 'Quote required'}\nPreferred date: ${_date!.day}/${_date!.month}/${_date!.year}\n\nThis is a demo. Your request has not been sent to the company.'),
        actions: [FilledButton(onPressed: () { Navigator.pop(dialogContext); Navigator.pop(context); }, child: const Text('Done'))],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final service = widget.service;
    final price = _property == null ? null : service.pricingByProperty[_property!];
    return Scaffold(
      appBar: AppBar(title: const Text('Book a service')),
      body: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 30), children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.primaryDarkBlue, borderRadius: BorderRadius.circular(20)),
          child: Row(children: [
            Container(width: 54, height: 54, decoration: BoxDecoration(color: Colors.white.withOpacity(.1), borderRadius: BorderRadius.circular(15)), child: Icon(service.icon, color: AppColors.yellow, size: 30)),
            const SizedBox(width: 14),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(service.title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
              const SizedBox(height: 4),
              Text(service.subtitle, style: TextStyle(color: Colors.white.withOpacity(.75), fontSize: 12)),
            ])),
          ]),
        ),
        const SizedBox(height: 20),
        const Text('Choose property size', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(
          value: _property,
          isExpanded: true,
          decoration: const InputDecoration(labelText: 'Property / site size'),
          items: service.pricingByProperty.keys.map((p) => DropdownMenuItem(value: p, child: Text(p))).toList(),
          onChanged: (value) => setState(() => _property = value),
        ),
        if (price != null) Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: AppColors.softGreen, borderRadius: BorderRadius.circular(14)),
            child: Row(children: [const Icon(Icons.currency_rupee_rounded, color: AppColors.primaryDarkBlue), const SizedBox(width: 8), Text('Indicative price: ₹$price', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primaryDarkBlue))])),
        ),
        const SizedBox(height: 22),
        const Text('Your details', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
        const SizedBox(height: 12),
        TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Full name', prefixIcon: Icon(Icons.person_outline))),
        const SizedBox(height: 12),
        TextField(controller: _phone, keyboardType: TextInputType.phone, maxLength: 10, decoration: const InputDecoration(labelText: '10-digit mobile number', prefixIcon: Icon(Icons.phone_outlined), counterText: '')),
        const SizedBox(height: 12),
        TextField(controller: _address, minLines: 2, maxLines: 3, decoration: const InputDecoration(labelText: 'Service address', prefixIcon: Icon(Icons.location_on_outlined), alignLabelWithHint: true)),
        const SizedBox(height: 12),
        TextField(controller: _notes, minLines: 2, maxLines: 3, decoration: const InputDecoration(labelText: 'Additional notes (optional)', alignLabelWithHint: true)),
        const SizedBox(height: 16),
        OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month_rounded), label: Text(_date == null ? 'Choose preferred date' : 'Preferred date: ${_date!.day}/${_date!.month}/${_date!.year}')),
        const SizedBox(height: 18),
        SizedBox(height: 54, child: FilledButton.icon(onPressed: _submit, icon: const Icon(Icons.check_circle_outline), label: const Text('Review booking request'))),
        const SizedBox(height: 12),
        const Text('Demo booking flow. No payment is collected and no booking is sent to a server.', textAlign: TextAlign.center, style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
      ]),
    );
  }
}
