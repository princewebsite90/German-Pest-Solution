import 'package:flutter/material.dart';

class PestServiceModel {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;
  final String imageUrl;
  final Map<String, int> pricingByProperty;
  final List<String> benefits;

  const PestServiceModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.imageUrl,
    required this.pricingByProperty,
    required this.benefits,
  });
}

// Demo prices only. Replace with the business's approved live price list.
const List<PestServiceModel> kPestServices = [
  PestServiceModel(
    id: 'general',
    title: 'General Pest Control',
    subtitle: 'Cockroach, ants and common household pests',
    icon: Icons.home_work_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=1000',
    pricingByProperty: {'1 BHK': 1350, '2 BHK': 1650, '3 BHK': 1800, '4 BHK': 2050},
    benefits: ['Home and office treatment', 'Technician inspection', 'Service details shared after booking'],
  ),
  PestServiceModel(
    id: 'termite',
    title: 'Anti-Termite Treatment',
    subtitle: 'Targeted termite control for homes and offices',
    icon: Icons.shield_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?w=1000',
    pricingByProperty: {'1 BHK': 1550, '2 BHK': 2250, '3 BHK': 2800},
    benefits: ['Termite inspection', 'Treatment plan based on site conditions', 'Warranty terms confirmed by the team'],
  ),
  PestServiceModel(
    id: 'rodent',
    title: 'Rodent Control',
    subtitle: 'Rodent inspection and control planning',
    icon: Icons.pest_control_rodent_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=1000',
    pricingByProperty: {'1 BHK': 799, '2 BHK': 1099, '3 BHK': 1399, 'Commercial': 2199},
    benefits: ['Inspection of activity areas', 'Control recommendations', 'Prevention guidance'],
  ),
  PestServiceModel(
    id: 'bedbugs',
    title: 'Bed Bug Treatment',
    subtitle: 'Inspection and targeted bed bug treatment',
    icon: Icons.bed_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?w=1000',
    pricingByProperty: {'1 BHK': 1199, '2 BHK': 1699, '3 BHK': 2199},
    benefits: ['Bed and furniture inspection', 'Preparation guidance', 'Follow-up requirements explained'],
  ),
  PestServiceModel(
    id: 'mosquito',
    title: 'Mosquito Control',
    subtitle: 'Mosquito control for suitable indoor and outdoor areas',
    icon: Icons.bug_report_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=1000',
    pricingByProperty: {'1 BHK': 699, '2 BHK': 999, '3 BHK': 1299, 'Society/Lawn': 2999},
    benefits: ['Site-specific assessment', 'Treatment method confirmed by technician', 'Prevention advice'],
  ),
  PestServiceModel(
    id: 'commercial',
    title: 'Commercial Pest Control',
    subtitle: 'Offices, clinics, restaurants and commercial sites',
    icon: Icons.domain_rounded,
    imageUrl: 'https://images.unsplash.com/photo-1497366216548-37526070297c?w=1000',
    pricingByProperty: {'Up to 1000 sqft': 1999, '2500 sqft': 3499, 'Enterprise': 5999},
    benefits: ['Site-specific plan', 'Scheduling coordinated with your team', 'Service documentation on request'],
  ),
];
