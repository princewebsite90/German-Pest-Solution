import 'package:flutter_riverpod/flutter_riverpod.dart';

final isAuthenticatedProvider = StateProvider<bool>((ref) => false);
final userPhoneProvider = StateProvider<String?>((ref) => null);
final selectedServiceProvider = StateProvider<String?>((ref) => null);
final homeDataLoadingProvider = FutureProvider<bool>((ref) async {
  await Future.delayed(const Duration(milliseconds: 900));
  return true;
});
