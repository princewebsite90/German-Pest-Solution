class AppConfig {
  static const String companyName = 'German Pest Solution';
  static const String website = 'https://germanpestsolution.com';
  static const String primaryPhone = '9870515182';
  static const String secondaryPhone = '9711545655';
}
