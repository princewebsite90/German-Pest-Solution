import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const primaryDarkBlue = Color(0xFF0A2540);
  static const secondaryBlue = Color(0xFF163E64);
  static const crispWhite = Color(0xFFFFFFFF);
  static const lightGreyBg = Color(0xFFF4F6F9);
  static const cardBorder = Color(0xFFE2E8F0);
  static const textPrimary = Color(0xFF0F172A);
  static const textSecondary = Color(0xFF64748B);
  static const successGreen = Color(0xFF10B981);
  static const softGreen = Color(0xFFD1FAE5);
  static const yellow = Color(0xFFF7D303);
}

class AppTheme {
  static ThemeData get lightTheme => ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: AppColors.lightGreyBg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: AppColors.primaryDarkBlue,
          primary: AppColors.primaryDarkBlue,
          secondary: AppColors.successGreen,
          surface: AppColors.crispWhite,
        ),
        textTheme: GoogleFonts.poppinsTextTheme().apply(
          bodyColor: AppColors.textPrimary,
          displayColor: AppColors.primaryDarkBlue,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: AppColors.lightGreyBg,
          foregroundColor: AppColors.primaryDarkBlue,
          centerTitle: false,
          elevation: 0,
        ),
        cardTheme: CardTheme(
          color: AppColors.crispWhite,
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
            side: const BorderSide(color: AppColors.cardBorder),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: AppColors.crispWhite,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.cardBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(14),
            borderSide: const BorderSide(color: AppColors.cardBorder),
          ),
          contentPadding: const EdgeInsets.all(16),
        ),
      );

  static List<BoxShadow> get softShadow => [
        BoxShadow(
          color: AppColors.primaryDarkBlue.withOpacity(0.06),
          blurRadius: 20,
          offset: const Offset(0, 8),
        ),
      ];
}
